--
-- All SQL statements must be on a single line and end in a semicolon.
--

-- Index Your Tables Here (Optional) --
CREATE INDEX mailbox_idx ON mail(mailbox);