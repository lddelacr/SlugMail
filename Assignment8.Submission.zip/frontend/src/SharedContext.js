import React from 'react';
const SharedContext = React.createContext();
export default SharedContext;
